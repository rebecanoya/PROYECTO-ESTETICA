<?php

include '../../src/BBDD.php';
include '../../src/sesion.php';
$BBDD = new BBDD();

$sesion = new Sesion();
