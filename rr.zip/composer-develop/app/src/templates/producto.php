<div class="producto" data-idProducto="<?php echo $IDProducto ?>" data-idLinea="<?php echo $IDLinea ?>" data-activo="true">

    <img src="../img/productos/<?php echo $IDProducto ?>.png" alt="">
    <p><?php echo $nombreProducto ?></p>
    <div class="opciones">

        <button class="compra" style="--colorFondo: #<?php echo $colorLinea ?>;">Comprar</button>
        <button class="muestra">Solicitar muestra</button>

    </div>
</div>