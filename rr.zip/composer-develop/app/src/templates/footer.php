<footer>

    <div class="chat">
        <a class="fa-solid fa-headset iconButton">
        </a>
    </div>

</footer>